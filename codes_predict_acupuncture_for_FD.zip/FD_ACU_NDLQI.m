%% This model was devoleped to predict the improvment of NDLQI
% We trained this model with 442 FD patients who recieve 4-week acupuncture treatment. You can find more details about those patients in this paper: 
% Ma TT, et al. Randomised clinical trial: an assessment of acupuncture on specific meridian or specific acupoint vs. sham acupuncture for treating functional dyspepsia. Aliment Pharmacol Ther. 2012.
% This SVR model was trained by the LIBSVM toolbox, See https://www.csie.ntu.edu.tw/~cjlin/Libsvm. when you use this code, you need to install the LIBSVM toolbox 
% How to use this mode:
% [predicted_label, accuracy] = svmpredict(test_label,test_data,FD_QOL_model);
% test_label is a n*1 matrix, which contains label of samples. n is the number of sample.
% test_data is a n*m matrix, n is the number of sample, m = 28, indicates the dimension of features
% predicted_label is the predicted label generated with the model and test_data.
% the second column of accuracy present the SME.
% the third column of accuracy present the R^2

clear;
clc;
load 'model_testdata_NDLQI.mat' % load the model and test data
% apply model to predict unseen data
[predicted_label, accuracy,~] = svmpredict(test_label,test_data,FD_QOL_model);
MSE= accuracy(2);
R2 = accuracy(3);
% plot the scatter between predicted label and actual label
figure;
scatter(predicted_label,test_label,'o')
p = polyfit(predicted_label,test_label,1);hold on;
y1 = polyval(p,predicted_label);
plot(predicted_label,y1);
xlabel('Predicted NDLQI improvment'); ylabel('Actual NDLQI improvment');
text(4,4,['R^2 = ',num2str(R2,'%.3f\n')]); hold off;