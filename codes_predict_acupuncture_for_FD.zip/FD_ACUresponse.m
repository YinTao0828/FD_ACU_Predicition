%% This model was devoleped to predict the Acupuncture response
% We trained this model with 442 FD patients who recieve 4-week acupuncture treatment. You can find more details about those patients in this paper: 
% Ma TT, et al. Randomised clinical trial: an assessment of acupuncture on specific meridian or specific acupoint vs. sham acupuncture for treating functional dyspepsia. Aliment Pharmacol Ther. 2012.
% This SVC model was trained by the LIBSVM toolbox, See https://www.csie.ntu.edu.tw/~cjlin/Libsvm. when you use this code, you need to install the LIBSVM toolbox 
% How to use this mode:
% [predicted_label, accuracy, deci] = svmpredict(test_label,test_data,model_FD_ResponsePrediction);
% test_label is a n*1 matrix, which contains label of samples. n is the number of sample.
% test_data is a n*m matrix, n is the number of sample, m = 28, indicates the dimension of features
% predicted_label is the predicted label generated with the model and test_data.
% the first column of accuracy present the classffication accuracy.
% deci is applied to fit the ROC curve.
clear clc
load 'model_testdata.mat' % load the model and test data
% apply model to predict unseen data
[predicted_label, accuracy, deci] = svmpredict(test_label,test_data,FD_ResponsePrediction_model)
Accuracy = accuracy(1)
Sensitivty = sum((test_label==1)&(predicted_label==1))/sum((test_label==1)&(predicted_label~=0))
Specificity = sum((test_label==-1)&(predicted_label==-1))/sum((test_label==-1)&(predicted_label~=0))
[X,Y,~,AUC] = perfcurve(test_label,deci,1);
% plot the ROC curve
figure;
plot(X,Y,'.-','color',[0,0,0]);hold on;
xlabel('False positive rate'); ylabel('True positive rate');
legend(['AUC = ',num2str(AUC,'%.3f\n')])
